<?php

/*
|--------------------------------------------------------------------------
| Developer Constants
|--------------------------------------------------------------------------
*/

defined('SERVER_ROOT')      or define('SERVER_ROOT', 'http://localhost/wechat/'); // highest automatically-assigned error code
defined('SERVER_ASSETS')      or define('SERVER_ASSETS', 'http://localhost/wechat/assets/'); // highest automatically-assigned error code
defined('STRIPE_PUBLISHABLE_KEY')      or define('STRIPE_PUBLISHABLE_KEY', 'pk_test_n5kGBnceS2DODJQlAUjLnIgQ00pebk2TNy'); // highest automatically-assigned error code
defined('STRIPE_SECRET_KEY')      or define('STRIPE_SECRET_KEY', 'sk_test_1r0I0HMdaVjbTX2t0QsZG4Ql006PiThqg6'); // highest automatically-assigned error code
